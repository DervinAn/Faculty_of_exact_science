﻿package com.example.facultyofexactscience.di

import android.util.Log
import com.example.facultyofexactscience.core.data.networking.HttpClientFactory
import com.example.facultyofexactscience.feature.faculty.data.remote.api.FacultyApi
import com.example.facultyofexactscience.feature.faculty.data.remote.service.FacultyApiImpl
import com.example.facultyofexactscience.feature.faculty.data.repository.EventsRepositoryImpl
import com.example.facultyofexactscience.feature.faculty.data.repository.QuotesRepositoryImpl
import com.example.facultyofexactscience.feature.faculty.domain.repository.EventsRepository
import com.example.facultyofexactscience.feature.faculty.domain.repository.QuotesRepository
import io.ktor.client.engine.okhttp.OkHttp

object AppModule {
    private val httpClient by lazy {
        // use OkHttp engine
        HttpClientFactory.create(OkHttp.create())
    }


    init {
        Log.d("AppModule", "AppModule.init block executed")
    }



    private val facultyApi: FacultyApi by lazy {
        Log.d("AppModule", "facultyApi lazy initializer executed")
        FacultyApiImpl(httpClient)
    }

    val eventsRepository: EventsRepository by lazy {
        Log.d("AppModule", "eventsRepository lazy initializer executed")
        EventsRepositoryImpl(facultyApi)
    }

    val quotesRepository: QuotesRepository by lazy {
        Log.d("AppModule", "quotesRepository lazy initializer executed")
        QuotesRepositoryImpl(facultyApi)
    }

    /** Call this once at app start if you want eager init */
    fun ensureInitialized() {
        Log.d("AppModule", "ensureInitialized() called")
        // Touch the properties to trigger lazy initialization
        @Suppress("UNUSED_VARIABLE")
        val init1 = eventsRepository
        @Suppress("UNUSED_VARIABLE")
        val init2 = quotesRepository
    }
}
